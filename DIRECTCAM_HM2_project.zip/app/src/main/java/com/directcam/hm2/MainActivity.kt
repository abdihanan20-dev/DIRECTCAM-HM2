package com.directcam.hm2

import android.Manifest
import android.app.Activity
import android.content.ContentValues
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.SurfaceTexture
import android.hardware.camera2.*
import android.media.ImageReader
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.HandlerThread
import android.provider.MediaStore
import android.view.Gravity
import android.view.Surface
import android.view.TextureView
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import java.io.OutputStream
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var texture: TextureView
    private lateinit var status: TextView
    private var camera: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var reader: ImageReader? = null
    private var bgThread: HandlerThread? = null
    private var bg: Handler? = null
    private var cameraId: String? = null
    private var jpegW = 4000
    private var jpegH = 3000
    private val pickImage = 42

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        texture.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(s: SurfaceTexture, w: Int, h: Int) { startCamera() }
            override fun onSurfaceTextureSizeChanged(s: SurfaceTexture, w: Int, h: Int) {}
            override fun onSurfaceTextureDestroyed(s: SurfaceTexture): Boolean = true
            override fun onSurfaceTextureUpdated(s: SurfaceTexture) {}
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF101114.toInt())
        }
        status = TextView(this).apply {
            text = "DIRECTCAM HM2  •  Auto Pink Correction"
            setTextColor(0xFFFFFFFF.toInt()); textSize = 16f
            gravity = Gravity.CENTER; setPadding(8, 14, 8, 14)
        }
        texture = TextureView(this)
        root.addView(status)
        root.addView(texture, LinearLayout.LayoutParams(-1, 0, 1f))
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL }
        val shoot = Button(this).apply { text = "FOTO + KOREKSI"; setOnClickListener { takePhoto() } }
        val gallery = Button(this).apply { text = "KOREKSI GALERI"; setOnClickListener { openGallery() } }
        row.addView(shoot, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(gallery, LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(row)
        val note = TextView(this).apply {
            text = "Versi awal: foto JPEG dikoreksi otomatis. RAW dan video 60 FPS perlu uji dukungan driver/ROM."
            setTextColor(0xFFCCCCCC.toInt()); textSize = 11f; gravity = Gravity.CENTER
            setPadding(10, 6, 10, 12)
        }
        root.addView(note)
        setContentView(root)
    }

    override fun onResume() { super.onResume(); startThread(); if (texture.isAvailable) startCamera() }
    override fun onPause() { closeCamera(); stopThread(); super.onPause() }

    private fun startThread() {
        if (bgThread != null) return
        bgThread = HandlerThread("DirectCamCamera").also { it.start(); bg = Handler(it.looper) }
    }
    private fun stopThread() { bgThread?.quitSafely(); try { bgThread?.join() } catch (_: Exception) {}; bgThread = null; bg = null }

    private fun startCamera() {
        if (!texture.isAvailable) return
        if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(Manifest.permission.CAMERA), 10); return
        }
        try {
            val manager = getSystemService(CAMERA_SERVICE) as CameraManager
            val ids = manager.cameraIdList
            cameraId = ids.firstOrNull { manager.getCameraCharacteristics(it).get(CameraCharacteristics.LENS_FACING) == CameraCharacteristics.LENS_FACING_BACK } ?: ids.first()
            val chars = manager.getCameraCharacteristics(cameraId!!)
            val map = chars.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)
            val sizes = map?.getOutputSizes(android.graphics.ImageFormat.JPEG)
            val largest = sizes?.maxByOrNull { it.width.toLong() * it.height.toLong() }
            if (largest != null) { jpegW = largest.width; jpegH = largest.height }
            reader?.close()
            reader = ImageReader.newInstance(jpegW, jpegH, android.graphics.ImageFormat.JPEG, 2).apply {
                setOnImageAvailableListener({ r ->
                    val image = r.acquireNextImage() ?: return@setOnImageAvailableListener
                    val bytes = image.planes[0].buffer.let { b -> ByteArray(b.remaining()).also { b.get(it) } }
                    image.close()
                    val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                    if (bmp != null) saveBitmap(PinkFix.correct(bmp), "DC_HM2")
                }, bg)
            }
            manager.openCamera(cameraId!!, object : CameraDevice.StateCallback() {
                override fun onOpened(c: CameraDevice) { camera = c; createPreview() }
                override fun onDisconnected(c: CameraDevice) { c.close(); camera = null }
                override fun onError(c: CameraDevice, error: Int) { c.close(); camera = null; toast("Kamera error: $error") }
            }, bg)
        } catch (e: Exception) { toast("Tidak bisa membuka kamera: ${e.message}") }
    }

    private fun createPreview() {
        val c = camera ?: return
        val st = texture.surfaceTexture ?: return
        st.setDefaultBufferSize(1280, 720)
        val preview = Surface(st)
        val jpeg = reader?.surface ?: return
        try {
            c.createCaptureSession(listOf(preview, jpeg), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    session = s
                    try {
                        val req = c.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                            addTarget(preview)
                            set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
                            set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                        }
                        s.setRepeatingRequest(req.build(), null, bg)
                        runOnUiThread { status.text = "DIRECTCAM HM2 • Kamera aktif • ${jpegW}×${jpegH}" }
                    } catch (e: Exception) { toast("Preview gagal: ${e.message}") }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) { toast("Konfigurasi kamera gagal") }
            }, bg)
        } catch (e: Exception) { toast("Session kamera gagal: ${e.message}") }
    }

    private fun takePhoto() {
        val c = camera ?: run { toast("Kamera belum siap"); return }
        val s = session ?: return
        val out = reader?.surface ?: return
        try {
            val req = c.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE).apply {
                addTarget(out)
                set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
                set(CaptureRequest.CONTROL_AF_MODE, CaptureRequest.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
                set(CaptureRequest.CONTROL_AE_MODE, CaptureRequest.CONTROL_AE_MODE_ON)
                set(CaptureRequest.JPEG_QUALITY, 98.toByte())
            }
            s.capture(req.build(), object : CameraCaptureSession.CaptureCallback() {
                override fun onCaptureFailed(session: CameraCaptureSession, request: CaptureRequest, failure: CaptureFailure) {
                    toast("Gagal mengambil foto")
                }
            }, bg)
        } catch (e: Exception) { toast("Capture gagal: ${e.message}") }
    }

    private fun openGallery() {
        val i = android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply {
            type = "image/*"; addCategory(android.content.Intent.CATEGORY_OPENABLE)
        }
        startActivityForResult(i, pickImage)
    }

    @Deprecated("Deprecated API retained for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: android.content.Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickImage && resultCode == RESULT_OK) {
            val uri: Uri = data?.data ?: return
            Thread {
                try {
                    val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it) }
                    if (bmp != null) saveBitmap(PinkFix.correct(bmp), "DC_FIX")
                } catch (e: Exception) { runOnUiThread { toast("Gagal koreksi: ${e.message}") } }
            }.start()
        }
    }

    private fun saveBitmap(bitmap: Bitmap, prefix: String) {
        try {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "${prefix}_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
                if (Build.VERSION.SDK_INT >= 29) put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DIRECTCAM_HM2")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values) ?: throw Exception("MediaStore gagal")
            val stream = contentResolver.openOutputStream(uri) ?: throw Exception("Tidak bisa membuka file hasil")\n            stream.use { bitmap.compress(Bitmap.CompressFormat.JPEG, 96, it) }
            runOnUiThread { toast("Tersimpan di Pictures/DIRECTCAM_HM2") }
        } catch (e: Exception) { runOnUiThread { toast("Gagal menyimpan: ${e.message}") } }
    }

    private fun closeCamera() {
        try { session?.close(); session = null; camera?.close(); camera = null; reader?.close(); reader = null } catch (_: Exception) {}
    }
    private fun toast(msg: String) { runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_LONG).show() } }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 10 && grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startCamera()
        else toast("Izin kamera diperlukan")
    }
}

private object PinkFix {
    // Conservative gray-world correction. It is a first-pass correction, not a calibrated HM2 sensor profile.
    fun correct(src: Bitmap): Bitmap {
        val sample = Bitmap.createScaledBitmap(src, min(96, src.width), min(96, src.height), true)
        val pixels = IntArray(sample.width * sample.height)
        sample.getPixels(pixels, 0, sample.width, 0, 0, sample.width, sample.height)
        var r = 0.0; var g = 0.0; var b = 0.0
        for (p in pixels) { r += (p shr 16 and 255); g += (p shr 8 and 255); b += (p and 255) }
        val n = max(1, pixels.size).toDouble()
        val ar = max(1.0, r / n); val ag = max(1.0, g / n); val ab = max(1.0, b / n)
        sample.recycle()
        val target = (ar + ag + ab) / 3.0
        val strength = 0.60
        val gr = (target / ar).coerceIn(0.78, 1.28).let { 1.0 + (it - 1.0) * strength }
        val gg = (target / ag).coerceIn(0.78, 1.28).let { 1.0 + (it - 1.0) * strength }
        val gb = (target / ab).coerceIn(0.78, 1.28).let { 1.0 + (it - 1.0) * strength }
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val row = IntArray(src.width)
        for (y in 0 until src.height) {
            src.getPixels(row, 0, src.width, 0, y, src.width, 1)
            for (x in row.indices) {
                val p = row[x]
                val rr = ((p shr 16 and 255) * gr).toInt().coerceIn(0, 255)
                val gg2 = ((p shr 8 and 255) * gg).toInt().coerceIn(0, 255)
                val bb = ((p and 255) * gb).toInt().coerceIn(0, 255)
                row[x] = (p and -0x1000000) or (rr shl 16) or (gg2 shl 8) or bb
            }
            out.setPixels(row, 0, src.width, 0, y, src.width, 1)
        }
        if (src !== out) src.recycle()
        return out
    }
}
