# DIRECTCAM HM2 (prototype 0.1)

Prototype Android app for Redmi Note 10 Pro / Android 15 testing.

## Included in this first prototype
- Camera2 back-camera preview and JPEG capture.
- Uses the largest JPEG output size advertised by the installed camera HAL.
- Conservative automatic global color-balance correction on captured JPEGs.
- Import an existing image through Android's document picker and save a corrected copy.
- Saves results under `Pictures/DIRECTCAM_HM2`.

## Important limitations
- This is **not yet a calibrated Samsung HM2 RAW pipeline**. Camera2 JPEG output is normally processed by the ROM camera HAL/ISP.
- RAW_SENSOR capture is not implemented in this prototype. It requires checking whether this ROM exposes RAW capability for the selected camera ID.
- Video recording / 60 FPS is not implemented in this first build. Actual 60 FPS support depends on the ROM camera HAL and supported stream configurations.
- The automatic correction is a conservative gray-world starting point. It can alter scenes whose real lighting or colors are strongly warm/cool; compare with the original and do not delete originals.
- The app has not been built or device-tested yet. Build success does not guarantee that the ROM exposes the desired sensor stream.

## Build on GitHub using a phone
1. Create a new **public** repository named `DIRECTCAM-HM2` on GitHub.
2. Upload the contents of this ZIP (not the enclosing folder) to the repository root.
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Select **Build DIRECTCAM HM2 APK**, tap **Run workflow**, then confirm.
5. When the run finishes green, open it and download the `DIRECTCAM-HM2-debug` artifact.
6. Extract the ZIP artifact; install `app-debug.apk`. Android may ask permission to install unknown apps from the browser/files app.

Do not publish signing keys or passwords in the repository. This debug APK is for personal testing only.
